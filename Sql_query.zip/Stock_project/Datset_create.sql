create database stock;
use stock;
CREATE TABLE reliance_stock (
    trade_date VARCHAR(20),
    open DECIMAL(10,2),
    high DECIMAL(10,2),
    low DECIMAL(10,2),
    close DECIMAL(10,2),
    adjclose DECIMAL(10,2),
    volume BIGINT,
    month INT,
    year INT,
    quarter INT,
    daily_change DECIMAL(10,2),
    price_range DECIMAL(10,2)
);
use stock;
UPDATE reliance_stock
SET trade_date = STR_TO_DATE(trade_date, '%d-%m-%Y');
SELECT trade_date, COUNT(*) 
FROM reliance_stock 
GROUP BY trade_date
LIMIT 5;
Select * from reliance_stock limit 3; 



