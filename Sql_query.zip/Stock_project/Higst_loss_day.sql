CREATE VIEW biggest_1_day_loss AS
SELECT
    trade_date,
    Year,
    (close - open) / open AS daily_return
FROM reliance_stock
ORDER BY daily_return ASC
LIMIT 1;
