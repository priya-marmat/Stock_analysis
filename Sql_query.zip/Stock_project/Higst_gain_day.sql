CREATE VIEW biggest_1_day_gain AS
SELECT
    trade_date,
    Year,
    (close - open) / open AS daily_return
FROM reliance_stock
ORDER BY daily_return DESC
LIMIT 1;
