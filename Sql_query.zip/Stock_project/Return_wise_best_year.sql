CREATE VIEW best_year AS
WITH yearly_prices AS (
    SELECT
        Year,
        FIRST_VALUE(close) OVER (
            PARTITION BY Year
            ORDER BY trade_date
        ) AS first_close,
        LAST_VALUE(close) OVER (
            PARTITION BY Year
            ORDER BY trade_date
            ROWS BETWEEN UNBOUNDED PRECEDING AND UNBOUNDED FOLLOWING
        ) AS last_close
    FROM reliance_stock
),
yearly_return AS (
    SELECT DISTINCT
        Year,
        (last_close - first_close) / first_close AS yearly_return
    FROM yearly_prices
)
SELECT *
FROM yearly_return
ORDER BY yearly_return DESC
LIMIT 1;


